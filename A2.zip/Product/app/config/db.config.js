module.exports = {
    url: "mongodb+srv://tlee143:BevNEvedlDzTdtVa@cluster0.p2ws7xp.mongodb.net/DressStore?retryWrites=true&w=majority"
};